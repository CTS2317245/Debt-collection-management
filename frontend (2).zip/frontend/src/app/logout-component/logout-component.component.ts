import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout-component',
  templateUrl: './logout-component.component.html',
  styleUrls: ['./logout-component.component.css']
})
export class LogoutComponentComponent implements OnInit {

  constructor(private router:Router, private authenticateservice:AuthenticationService) { }

  ngOnInit(): void {
    this.authenticateservice.logOut()
    this.router.navigate(['login']);
  }

}
