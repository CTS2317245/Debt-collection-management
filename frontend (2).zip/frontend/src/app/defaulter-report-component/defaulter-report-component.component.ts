import { Component, OnInit } from '@angular/core';
import { Debt } from '../model/Debt';
import { DebtServiceService } from '../debt-service.service';

@Component({
  selector: 'app-defaulter-report-component',
  templateUrl: './defaulter-report-component.component.html',
  styleUrls: ['./defaulter-report-component.component.css']
})
export class DefaulterReportComponentComponent implements OnInit {

  month!: number;
  year!: number;
  debts!: Debt[];
  showTable: boolean = false;
  flag:boolean =  false;
  curryear:number=new Date().getFullYear();
  constructor(private debtServiceService: DebtServiceService) { }
  check() {
    if(this.month>=1 && this.month<=12 && this.year.toString().length ==4 && this.year>1999)
    return true;
    return false
    }
  getdefaulters(){
    this.debtServiceService.getDebtDefaulters(this.month,this.year).
    subscribe(data=>{
      this.debts=data;
    });
    this.toggleShowTable();
  }
  ngOnInit(): void {
  }
  toggleShowTable(){
    this.showTable = !this.showTable;
  }
}
