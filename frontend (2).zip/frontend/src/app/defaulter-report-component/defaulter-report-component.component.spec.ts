import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaulterReportComponentComponent } from './defaulter-report-component.component';

describe('DefaulterReportComponentComponent', () => {
  let component: DefaulterReportComponentComponent;
  let fixture: ComponentFixture<DefaulterReportComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaulterReportComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DefaulterReportComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
