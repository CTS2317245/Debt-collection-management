export class Debt{
    paymentTrackId!:string;
    loanAppId!:string;
    month_no!:number;
    status!:string;
    dueDateofPayment!:Date;
    paymentReceiveDate!:Date
}