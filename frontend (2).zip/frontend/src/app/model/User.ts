export class User{
    userName!: number;
    password!: string;
    isAccountLocked!:boolean;
}