import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DuesListComponentComponent } from './dues-list-component.component';

describe('DuesListComponentComponent', () => {
  let component: DuesListComponentComponent;
  let fixture: ComponentFixture<DuesListComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DuesListComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DuesListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
