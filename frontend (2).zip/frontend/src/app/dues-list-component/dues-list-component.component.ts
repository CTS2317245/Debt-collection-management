import { Component, OnInit } from '@angular/core';
import { DebtServiceService } from '../debt-service.service';
import { Debt } from '../model/Debt';

@Component({
  selector: 'app-dues-list-component',
  templateUrl: './dues-list-component.component.html',
  styleUrls: ['./dues-list-component.component.css']
})
export class DuesListComponentComponent implements OnInit {
month!: number;
year!: number;
debts!: Debt[];
curryear:number=new Date().getFullYear();
showTable: boolean = false;
  constructor(private debtServiceService: DebtServiceService) { 

  }

  ngOnInit(): void {
  }
  check() {
    if(this.month>=1 && this.month<=12 && this.year.toString().length ==4 && this.year>1999)
    return true;
    return false
    }
  getDues(){
    this.debtServiceService.getDueList(this.month,this.year).subscribe(
      data=> this.debts=data
    )
    this.toggleShowTable();
  }
  toggleShowTable(){
    this.showTable = !this.showTable;
  }
}
