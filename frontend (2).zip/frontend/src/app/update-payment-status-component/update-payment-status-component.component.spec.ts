import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePaymentStatusComponentComponent } from './update-payment-status-component.component';

describe('UpdatePaymentStatusComponentComponent', () => {
  let component: UpdatePaymentStatusComponentComponent;
  let fixture: ComponentFixture<UpdatePaymentStatusComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatePaymentStatusComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdatePaymentStatusComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
