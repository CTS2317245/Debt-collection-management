import { Component, OnInit } from '@angular/core';
import { DebtServiceService } from '../debt-service.service';
import { Debt } from '../model/Debt';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-update-payment-status-component',
  templateUrl: './update-payment-status-component.component.html',
  styleUrls: ['./update-payment-status-component.component.css']
})
export class UpdatePaymentStatusComponentComponent implements OnInit {
  month!: number;
  year!: number;
  debts!: Debt[];
  id!: string;
  curryear:number=new Date().getFullYear();
  showTable: boolean = false;
  constructor(private modalService: NgbModal, private debtServiceService: DebtServiceService) { }


  getdata() {
   
    this.debtServiceService.getDebtbyMonth(this.month, this.year).
      subscribe(data => {
        console.log(this.month);
        console.log(this.year);
        this.debts=data;
        console.log(this.debts);
        console.log(this.debts[0].status);
  })
  this.toggleShowTable();
}
check() {
  if(this.month>=1 && this.month<=12 && this.year.toString().length ==4 && this.year>1999)
  return true;
  return false
  }
   async updateDebt(id:string){
    let pr = new Promise<void>((resolve,reject)=>{
      this.debtServiceService.updateDebtbyId(id).subscribe(data=>resolve(),err=>reject(err))
    })
    pr.then(()=>{
      this.getdata();
    }).catch((err)=>{
      console.log(err);
    })
  }
  toggleShowTable(){
    this.showTable = !this.showTable;

  }
  ngOnInit(): void {
  }

}
function resolve(): void {
  throw new Error('Function not implemented.');
}

