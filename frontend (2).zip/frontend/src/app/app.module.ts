import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UpdatePaymentStatusComponentComponent } from './update-payment-status-component/update-payment-status-component.component';
import { DebtServiceService } from './debt-service.service';
import {HttpClientModule} from "@angular/common/http";
import { CreateDebtComponentComponent } from './create-debt-component/create-debt-component.component';
import { DefaulterReportComponentComponent } from './defaulter-report-component/defaulter-report-component.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DuesListComponentComponent } from './dues-list-component/dues-list-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { LogoutComponentComponent } from './logout-component/logout-component.component';
import { NavbarComponent } from './navbar/navbar.component';
import { InvalidLinkComponent } from './invalid-link/invalid-link.component';

@NgModule({
  declarations: [
    AppComponent,
    UpdatePaymentStatusComponentComponent,
    CreateDebtComponentComponent,
    DefaulterReportComponentComponent,
    DuesListComponentComponent,
    LoginComponentComponent,
    LogoutComponentComponent,
    NavbarComponent,
    InvalidLinkComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [DebtServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
