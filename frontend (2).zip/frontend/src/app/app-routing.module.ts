import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UpdatePaymentStatusComponentComponent } from './update-payment-status-component/update-payment-status-component.component';
import { CreateDebtComponentComponent } from './create-debt-component/create-debt-component.component';
import { DefaulterReportComponentComponent } from './defaulter-report-component/defaulter-report-component.component';
import { DuesListComponentComponent } from './dues-list-component/dues-list-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { AuthGuardService } from './auth-guard.service';
import { LogoutComponentComponent } from './logout-component/logout-component.component';
import { InvalidLinkComponent } from './invalid-link/invalid-link.component';

const routes: Routes = [
  {path: "updatestatus", component: UpdatePaymentStatusComponentComponent,canActivate: [AuthGuardService]},
  {path: "", component: LoginComponentComponent},
  {path: "create", component:CreateDebtComponentComponent,canActivate: [AuthGuardService]},
  {path:"getdefaulters",component:DefaulterReportComponentComponent,canActivate: [AuthGuardService]},
  { path: 'login', component: LoginComponentComponent},
  {path:"getDues",component:DuesListComponentComponent,canActivate: [AuthGuardService]},
  { path: 'logout', component: LogoutComponentComponent},
  {path:'**',component:InvalidLinkComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
