import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateDebtComponentComponent } from './create-debt-component.component';

describe('CreateDebtComponentComponent', () => {
  let component: CreateDebtComponentComponent;
  let fixture: ComponentFixture<CreateDebtComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateDebtComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateDebtComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
