import { Component, OnInit } from '@angular/core';
import { Debt } from '../model/Debt';
import { DebtServiceService } from '../debt-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PastorPresent } from '../Validator/pastorpresent';
@Component({
  selector: 'app-create-debt-component',
  templateUrl: './create-debt-component.component.html',
  styleUrls: ['./create-debt-component.component.css']
})
export class CreateDebtComponentComponent implements OnInit {
  formData!: FormGroup;
  debt: Debt = new Debt()
  issubmit!: boolean
  message!: string
  flag: boolean = false
  constructor(private debtServiceService: DebtServiceService) { }

  ngOnInit(): void {
    this.issubmit = false
    this.formData = new FormGroup(
      {
        loanAppId: new FormControl("", Validators.compose(
          [
            Validators.required,
            Validators.minLength(5),
            Validators.maxLength(10),
            Validators.pattern('^[a-zA-Z0-9]*$')
          ]
        )),
        paymentTrackId: new FormControl("", Validators.compose(
          [
            Validators.required,
            Validators.minLength(5),
            Validators.maxLength(10),
            Validators.pattern('^[a-zA-Z0-9]*$')
          ]
        )),
        month_no: new FormControl("", Validators.compose(
          [
            Validators.required,
            Validators.min(1),
            Validators.max(12)
          ]
        )),
        status: new FormControl("Received", Validators.compose(
          [
            Validators.required
          ]
        )),
        dueDateofPayment: new FormControl("", Validators.compose(
          [
            Validators.required
          ]
        )),
        paymentReceiveDate: new FormControl(null, Validators.compose(
          [Validators.required,
            PastorPresent
          ]))
      }
    );
    console.log(this.formData.invalid);
  }

  changedatevalidation(): any {
    console.log(this.formData.get('status')?.value);
    let statusvalue = this.formData.get('status')?.value;
    if (statusvalue === 'Received') {
      this.formData.get('paymentReceiveDate')?.setValidators([Validators.required,
        PastorPresent])
      this.formData.get('paymentReceiveDate')?.updateValueAndValidity()
    }
    else if (statusvalue === 'Not Received') {
      this.formData.get('paymentReceiveDate')?.setValidators([])
      this.formData.get('paymentReceiveDate')?.updateValueAndValidity()
    }
  };
  createdebt(data: { loanAppId: string; paymentTrackId: string; month_no: number; status: string; dueDateofPayment: Date; paymentReceiveDate: Date; }) {
    console.log(this.formData.invalid);
    if (this.formData.valid)
      console.log("valid");
    else {
      console.log("not valid");
    }
    console.log(data);
    this.issubmit = true
    this.debtServiceService.createDebt(data).subscribe(() => {
       this.formData.setValue({ loanAppId: '', paymentTrackId: '', month_no: '', status: 'Received', dueDateofPayment: '', paymentReceiveDate: '' })
      // this.formData=new FormGroup();
      this.flag=true
      setTimeout(() => this.flag = false, 3000)
    }, () => alert("Error!!! Record not inserted")
      // this.message="Record Inserted Succesfully"
    );

    // this.debt.loanAppId=data.loanAppId;
    // this.debt.paymentTrackId=data.paymentTrackId;
    // this.debt.month_no=data.month_no;
    // this.debt.status=data.status;
    // this.debt.dueDateofPayment=data.dueDateofPayment;
    // this.debt.paymentReceiveDate=data.paymentReceiveDate;
    // this.debtServiceService.createDebt(this.debt);
  }
  // get loanAppId():FormControl{
  //   return this.formData.get('loanAppId');
  // }
}
