import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Debt } from './model/Debt';
import { Observable } from 'rxjs';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class DebtServiceService {
  private getDebtURL = 'http://localhost:2345/api/debtCollection/pull';
  private updateDebtURL = 'http://localhost:2345/api/debtCollection/update';
  private createDebtURL = 'http://localhost:2345/api/debtCollection/create';
  private getDefaultersURL = 'http://localhost:2345/api/debtCollection/listOfDefaulters';
  private getDuesURL = 'http://localhost:2345/api/debtCollection/listOfDues';
   constructor(private http:HttpClient) {  }

  getDebtbyMonth(month:number,year:number){
    return this.http.get<Debt[]>(this.getDebtURL+'/'+month+'/'+year)
  }

  updateDebtbyId(id:string){
    console.log("inside service update");
    return this.http.patch(this.updateDebtURL,id)
  }

  createDebt(debt:Debt){
    console.log("inside create func");
    return this.http.post<any>(this.createDebtURL,debt)
  }
  getDebtDefaulters(month:number,year:number){
    console.log("inside getDebtDefaulters");
    return this.http.get<Debt[]>(this.getDefaultersURL+'/'+month+'/'+year)
  }
  getDueList(month:number,year:number){
    return this.http.get<Debt[]>(this.getDuesURL+'/'+month+'/'+year)
  }
}
