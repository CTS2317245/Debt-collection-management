import { Injectable } from '@angular/core';
import { User } from './model/User';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) { }
  authenticateURL: string = "http://localhost:2345/authenticate/users";
  user!: User;
  authenticated!: boolean;
  users!: User[];
  userBackend!: User;
  func(username: any, password: any) {
    let prm = new Promise<boolean>((resolve, reject) => {
      this.http.post<User>(this.authenticateURL, this.user)
        .subscribe((data) => {
          this.userBackend = new User();
          this.userBackend.userName = data.userName;
          this.userBackend.password = data.password;

          if (this.user.userName === this.userBackend.userName && this.user.password == this.userBackend.password) {
            this.authenticated = true;
            console.log(this.authenticated)

            sessionStorage.setItem('username', username);

            resolve(true);
          }
          else {
            console.log("inside else");
            
            this.authenticated = false;
            console.log()
            reject(false)
          }
        }, error => {
          console.log("inside error");
          
          window.alert('wrong username or password');
        })
    })
    return prm;
  }
  
  authenticate(username: any, password: any) {
    this.user=new User();
    this.user.userName=username;
    this.user.password=password;
    let prm = new Promise<boolean>((resolve, reject) => {
      this.http.post<User>(this.authenticateURL, this.user)
        .subscribe((data) => {
          this.userBackend = new User();
          this.userBackend.userName = data.userName;
          this.userBackend.password = data.password;
          console.log("inside subscribe");
          
          if (this.user.userName === this.userBackend.userName && this.user.password == this.userBackend.password) {
            this.authenticated = true;
            console.log(this.authenticated)

            sessionStorage.setItem('username', username);

            resolve(true);
          }
          else {
            console.log("inide else");
            
            this.authenticated = false;
            reject(false)
          }
        }, () => {
          window.alert('wrong username or password');
        })
    })
    return prm;
  }



  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    return !(user === null);
  }


  logOut() {
    sessionStorage.removeItem('username')
  }
}
