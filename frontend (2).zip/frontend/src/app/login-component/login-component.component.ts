import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  username = ''
  password = ''
 
  constructor(private router:Router,private loginservice:AuthenticationService) { }

  ngOnInit(): void {
    if(this.loginservice.isUserLoggedIn()){
      this.router.navigate(['updatestatus']);
    }
  }
  checkLogin() {
    debugger;
    console.log("fhfhfhf");
    
    // if(await this.loginservice.authenticate(this.username, this.password)){
    //   console.log("sfsf");
    //   this.router.navigate(['updatestatus']);
    // }
    this.loginservice.authenticate(this.username, this.password).then(()=>{
      console.log("sfsf");
      this.router.navigate(['updatestatus']);
    }).catch(()=>{
      window.alert('wrong username or password');
    })
}
}
