import { FormControl, ValidationErrors } from "@angular/forms";

export function  PastorPresent(control:FormControl) :ValidationErrors | null{
    if (control?.value) {
        const today = new Date();
        const dateToCheck = new Date(control.value);
    
        if (dateToCheck > today) {
          return { 'Invalid-date': true };
        }
      }
    return null
}