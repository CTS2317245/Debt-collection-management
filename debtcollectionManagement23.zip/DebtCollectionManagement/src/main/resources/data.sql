Insert into Debt values ('track101','loan201',3,'Received','2024-03-15','2024-03-14');
Insert into Debt values ('track102','loan202',3,'Received','2024-03-15','2024-03-12');
Insert into Debt(payment_track_id,loan_app_id,month_no,debt_status,due_date_of_payment) values ('track103','loan203',3,'Not Received','2024-03-10');
Insert into Debt(payment_track_id,loan_app_id,month_no,debt_status,due_date_of_payment) values ('track104','loan204',3,'Not Received','2024-03-10');
Insert into Debt values ('track105','loan205',3,'Received','2024-03-15','2024-03-17');
Insert into Debt values ('track108','loan208',3,'Received','2024-03-15','2024-03-22');
Insert into Debt values ('track106','loan206',2,'Received','2024-02-15','2024-02-20');
Insert into Debt values ('track107','loan207',2,'Received','2024-02-15','2024-02-10');
Insert into Debt values ('track109','loan209',9,'Received','2018-09-10','2018-09-22');
Insert into Debt(payment_track_id,loan_app_id,month_no,debt_status,due_date_of_payment) values ('track108','loan208',2,'Not Received','2024-02-10');
Insert into users(user_name,password,is_Account_Locked) values ('yash','yash@123',false);


