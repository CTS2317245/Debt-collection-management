create table Debt(
	loan_app_id varchar(10)  primary key,
	payment_track_id varchar(10) not null,
	month_no int not null,
	debt_status varchar(20) not null,
	due_date_of_payment DATE not null,
	payment_receive_date DATE
);

create table Users(
  user_name varchar(20) primary key,
  password varchar(10),
  is_Account_Locked BOOLEAN
);