package com.cognizant.debtcollectionmanagement.exception;

public class NoDebtUserFindException extends RuntimeException{
	public NoDebtUserFindException(String loanAppId) {
		super("No User find with Loan Id "+loanAppId);
	}
	public NoDebtUserFindException(int  month) {
		super("No User find with month "+month);
	}
}
