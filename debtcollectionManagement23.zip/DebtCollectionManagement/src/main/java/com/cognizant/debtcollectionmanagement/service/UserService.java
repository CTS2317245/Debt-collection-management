package com.cognizant.debtcollectionmanagement.service;

import java.util.List;

import com.cognizant.debtcollectionmanagement.entity.Users;
import com.cognizant.debtcollectionmanagement.model.UserDto;



public interface UserService {
	public List<Users> listOfUsers();
	public UserDto authenticateUser(String username,String password);

}
