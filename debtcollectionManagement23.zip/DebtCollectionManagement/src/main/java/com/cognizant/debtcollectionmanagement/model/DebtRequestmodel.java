package com.cognizant.debtcollectionmanagement.model;

import java.time.LocalDate;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.PastOrPresent;
import lombok.Data;

@Data
public class DebtRequestmodel {
	@NotEmpty(message="Payment track id cannot be empty or null")
	private String paymentTrackId;
	@NotEmpty(message="loanAppId cannot be empty or null")
	private String loanAppId;
	@Min(value=1,message="Month must be greater than or equal to 1")
	@Max(value=12,message="Month must be smaller than or equal to 12")
	private int month_no;
	@NotEmpty(message="status cannot be empty or null")
	private String status;
	private LocalDate dueDateofPayment;
	@PastOrPresent
	private LocalDate paymentReceiveDate;

}
