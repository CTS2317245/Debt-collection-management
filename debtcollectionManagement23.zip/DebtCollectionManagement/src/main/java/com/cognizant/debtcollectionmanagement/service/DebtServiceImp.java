package com.cognizant.debtcollectionmanagement.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.debtcollectionmanagement.entity.Debt;
import com.cognizant.debtcollectionmanagement.exception.NoDebtUserFindException;
import com.cognizant.debtcollectionmanagement.model.DebtRequestmodel;
import com.cognizant.debtcollectionmanagement.model.DebtResponsemodel;
import com.cognizant.debtcollectionmanagement.repository.DebtRepository;

@Service
public class DebtServiceImp implements DebtService {
	
	@Autowired
	private DebtRepository debtRepository;
	@Override
	public List<DebtResponsemodel> getDebtResponseModels(int month, int year) {
		Iterable<Debt> debtList=debtRepository.findbymonth(month,year);
		List<DebtResponsemodel> debtResponsemodelist = new ArrayList<>();
		debtResponsemodelist.forEach((v)->{
			System.out.println(v);
		});
		Iterator<Debt> iteratorOfDebt=debtList.iterator(); 
		while(iteratorOfDebt.hasNext())
		{
			Debt debt = iteratorOfDebt.next();
			DebtResponsemodel debtResponsemodel = new DebtResponsemodel();
			debtResponsemodel.setPaymentTrackId(debt.getPaymentTrackId());
			debtResponsemodel.setLoanAppId(debt.getLoanAppId());
			debtResponsemodel.setMonth_no(debt.getMonth_no());
			debtResponsemodel.setDueDateofPayment(debt.getDueDateofPayment());
			debtResponsemodel.setPaymentReceiveDate(debt.getPaymentReceiveDate());
			debtResponsemodel.setStatus(debt.getStatus());
			debtResponsemodelist.add(debtResponsemodel);
		}
		return debtResponsemodelist;
	}

	@Override
	public String createDebtRequest(DebtRequestmodel debtRequest) {
		Debt debtCreated=null;
		Debt debt = new Debt();
		System.out.println("inside service");
		Optional<Debt> checkid = debtRepository.findById(debtRequest.getLoanAppId());
		if(checkid.isEmpty())
		{
		System.out.println("inside if");
		debt.setPaymentTrackId(debtRequest.getPaymentTrackId());
		debt.setLoanAppId(debtRequest.getLoanAppId());
		debt.setMonth_no(debtRequest.getMonth_no());
		debt.setDueDateofPayment(debtRequest.getDueDateofPayment());
		debt.setPaymentReceiveDate(debtRequest.getPaymentReceiveDate());
		debt.setStatus(debtRequest.getStatus());
		debtCreated=debtRepository.save(debt);
		System.out.println(debtCreated);
		}
		if(debtCreated!=null) {
			return "success";
		}
		else {
		return "fail";
		}
	}
	@Override
	public String updateDebtById(String loanAppId) {
		Optional<Debt> optionalOfDebt = debtRepository.findById(loanAppId);
		Debt debtupdated = null;
		if(optionalOfDebt.isPresent()) {
			Debt debt = optionalOfDebt.get();
			if(debt.getStatus().equals("Not Received")) {
				debt.setStatus("Received");
				debt.setPaymentReceiveDate(LocalDate.now());
				
		}else if(debt.getStatus().equals("Received")) {
			debt.setStatus("Not Received");
			debt.setPaymentReceiveDate(null);
		}
			debtupdated = debtRepository.save(debt);
		}
		if(debtupdated!=null) {
			return "success";
		}
		return "fail";
	}
	

	@Override
	public List<DebtResponsemodel> getDebtDefaulters(int month,int year) {
		List<DebtResponsemodel> debtResponsemodelist = new ArrayList<>();
		try {
			LocalDate currDate = LocalDate.now();
		List<Debt> debtDefaulters= debtRepository.findAllDefaulters(month,year,currDate);
		for(Debt debt:debtDefaulters) {
			DebtResponsemodel debtResponsemodel = new DebtResponsemodel();
			debtResponsemodel.setPaymentTrackId(debt.getPaymentTrackId());
			debtResponsemodel.setLoanAppId(debt.getLoanAppId());
			debtResponsemodel.setMonth_no(debt.getMonth_no());
			debtResponsemodel.setDueDateofPayment(debt.getDueDateofPayment());
			debtResponsemodel.setPaymentReceiveDate(debt.getPaymentReceiveDate());
			debtResponsemodel.setStatus(debt.getStatus());
			debtResponsemodelist.add(debtResponsemodel);
		}
		return debtResponsemodelist;
		}catch(Exception e) {
			throw new NoDebtUserFindException(month);
		}
	}

	@Override
	public List<DebtResponsemodel> getDuesData(int month, int year) {
		List<DebtResponsemodel> debtResponsemodelist = new ArrayList<>();
		try {
		LocalDate currDate = LocalDate.now();
		List<Debt> debtDefaulters= debtRepository.findAllDues(month,year,currDate);
		for(Debt debt:debtDefaulters) {
			DebtResponsemodel debtResponsemodel = new DebtResponsemodel();
			debtResponsemodel.setPaymentTrackId(debt.getPaymentTrackId());
			debtResponsemodel.setLoanAppId(debt.getLoanAppId());
			debtResponsemodel.setMonth_no(debt.getMonth_no());
			debtResponsemodel.setDueDateofPayment(debt.getDueDateofPayment());
			debtResponsemodel.setPaymentReceiveDate(debt.getPaymentReceiveDate());
			debtResponsemodel.setStatus(debt.getStatus());
			debtResponsemodelist.add(debtResponsemodel);
		}
		return debtResponsemodelist;
		}catch(Exception e) {
			throw new NoDebtUserFindException(month);
		}
	}
}
