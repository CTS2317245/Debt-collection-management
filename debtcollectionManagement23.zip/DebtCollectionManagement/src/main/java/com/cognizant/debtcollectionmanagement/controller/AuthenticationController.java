package com.cognizant.debtcollectionmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.debtcollectionmanagement.model.UserDto;
import com.cognizant.debtcollectionmanagement.model.UserRequest;
import com.cognizant.debtcollectionmanagement.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("authenticate")

public class AuthenticationController {
	@Autowired
	private UserService userService;
	
	@Operation(description="Authenticate the user")
	@PostMapping("users")
	public ResponseEntity<?> authenticate(@RequestBody UserRequest userRequest){
		System.out.println("inside auth controller");
		UserDto userDto=userService.authenticateUser(userRequest.getUserName(), userRequest.getPassword());
		if(userDto.getUserName()!=null) {
			return new ResponseEntity<UserDto>(userDto,HttpStatus.ACCEPTED);
		}else {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}
	}
}
