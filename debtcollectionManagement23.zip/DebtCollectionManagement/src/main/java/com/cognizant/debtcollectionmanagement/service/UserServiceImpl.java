package com.cognizant.debtcollectionmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.debtcollectionmanagement.entity.Users;
import com.cognizant.debtcollectionmanagement.model.UserDto;
import com.cognizant.debtcollectionmanagement.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepository;
	
	@Override
	public List<Users> listOfUsers() {
		// TODO Auto-generated method stub
		return (List<Users>) userRepository.findAll();
	}

	@Override
	public UserDto authenticateUser(String username, String password) {
		// TODO Auto-generated method stub
		List<Users> users= listOfUsers();
		UserDto userModel=new UserDto();
		for(Users user:users) {
			if(user.getUserName().equals(username) && user.getPassword().equals(password) && !user.isAccountLocked()) {
				userModel.setUserName(user.getUserName());
				userModel.setPassword(user.getPassword());
				userModel.setAccountLocked(user.isAccountLocked());
				break;
			}
		}
		return userModel;
	}

}
