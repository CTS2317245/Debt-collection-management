package com.cognizant.debtcollectionmanagement.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.debtcollectionmanagement.exception.NoDebtUserFindException;
import com.cognizant.debtcollectionmanagement.model.DebtRequestmodel;
import com.cognizant.debtcollectionmanagement.model.DebtResponsemodel;
import com.cognizant.debtcollectionmanagement.model.GetRequestDto;
import com.cognizant.debtcollectionmanagement.service.DebtService;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("api/debtCollection")
@OpenAPIDefinition(info=@Info(title="Debt Collection Management  Rest APIs"))
@Tag(name="Bank Landing Portal",description="Rest API of Debt Collection Management")
public class DebtController {
	
	@Autowired
	private DebtService debtService;
	
	@Operation(description="Gets the monthly record")
	@GetMapping("pull/{month}/{year}")
	public ResponseEntity<?> handleGetAllDebt(@PathVariable("month") int month,@PathVariable("year") int year){
		List<DebtResponsemodel> responseList=debtService.getDebtResponseModels(month,year);
		if(!responseList.isEmpty()) {
			return new ResponseEntity<List<DebtResponsemodel>>(responseList,HttpStatus.OK);
		}
			return new ResponseEntity<String>(new HashMap<String,String>().put("result", "No data found"),HttpStatus.NO_CONTENT);
	}
	
	@Operation(description="Create the monthly tracking record")
	@PostMapping("create")
	public ResponseEntity<?> persistDebt(@RequestBody @Valid DebtRequestmodel debtRequestmodel){
		System.out.println("inside create controller");
		String result=debtService.createDebtRequest(debtRequestmodel);
		Map<String,String> map=new HashMap<>();
		map.put("result","Record inserted successfully!");
		if(result.equals("success")) {
			return new ResponseEntity<>(map,HttpStatus.CREATED);
		}else 
			return new ResponseEntity<>(new HashMap<String,String>().put("result","Record not inserted! Please try again."),HttpStatus.BAD_REQUEST);		
	}
	
	@Operation(description="Updates the staus of a debt user")
	@PatchMapping("update")
	public ResponseEntity<?> updateDebt(@RequestBody String loanAppId){
		String response = debtService.updateDebtById(loanAppId);
		if(response=="success") {
			Map<String,String> map=new HashMap<>();
			map.put("result","Status updated successfully!");
		return new ResponseEntity<>(map,HttpStatus.OK);
		}
		else
			throw new NoDebtUserFindException(loanAppId);	
	}
	
	@Operation(description="Get the list of the defaulters")
	@GetMapping("listOfDefaulters/{month}/{year}")
	public ResponseEntity<?> getlistOfDefaulters(@PathVariable("month") int month,@PathVariable("year") int year){
		List<DebtResponsemodel> responseList = new ArrayList<>();
		responseList=debtService.getDebtDefaulters(month,year);
		if(!responseList.isEmpty())
		return new ResponseEntity<>(responseList,HttpStatus.OK);
		return new ResponseEntity<>(responseList,HttpStatus.NO_CONTENT);
	}
	
	@Operation(description="Get the user whose installment is due")
	@GetMapping("listOfDues/{month}/{year}")
	public ResponseEntity<?> getlistOfDues(@PathVariable("month") int month,@PathVariable("year") int year){
		List<DebtResponsemodel> responseList = new ArrayList<>();
		responseList=debtService.getDuesData(month,year);
		if(!responseList.isEmpty())
		return new ResponseEntity<>(responseList,HttpStatus.OK);
		return new ResponseEntity<>(responseList,HttpStatus.NO_CONTENT);
	}
	}
