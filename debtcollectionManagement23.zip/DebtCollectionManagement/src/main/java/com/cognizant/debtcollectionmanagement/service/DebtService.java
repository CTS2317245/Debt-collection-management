package com.cognizant.debtcollectionmanagement.service;


import java.util.List;

import com.cognizant.debtcollectionmanagement.model.DebtRequestmodel;
import com.cognizant.debtcollectionmanagement.model.DebtResponsemodel;

public interface DebtService {
	List<DebtResponsemodel> getDebtResponseModels(int month, int year);
	String createDebtRequest(DebtRequestmodel debtRequest);
	String updateDebtById(String loanAppId);
	List<DebtResponsemodel> getDebtDefaulters(int month, int year);
	List<DebtResponsemodel> getDuesData(int month, int year);
}
