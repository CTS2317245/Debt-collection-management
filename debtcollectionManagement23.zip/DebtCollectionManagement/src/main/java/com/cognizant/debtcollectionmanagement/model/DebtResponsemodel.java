package com.cognizant.debtcollectionmanagement.model;

import java.time.LocalDate;

import lombok.Data;

@Data
public class DebtResponsemodel {
	private String paymentTrackId;
	private String loanAppId;
	private int month_no;
	private String status;
	private LocalDate dueDateofPayment;
	private LocalDate paymentReceiveDate;
}
