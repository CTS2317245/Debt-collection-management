package com.cognizant.debtcollectionmanagement.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Debt {
	
	@Column(name="payment_track_id")
	private String paymentTrackId;
	@Id
	@Column(name="loan_app_id")
	private String loanAppId;
	@Column(name="month_no")
	private int month_no;
	@Column(name="debt_status", columnDefinition = "Varchar(23) default 'Not Received'")
	private String status;
	@Column(name="due_date_of_payment")
	private LocalDate dueDateofPayment;
	@Column(name="payment_receive_date")
	private LocalDate paymentReceiveDate;
	
	
}


