package com.cognizant.debtcollectionmanagement.model;

import lombok.Data;

@Data
public class GetRequestDto {
	private int month;
	private int year;
}
