package com.cognizant.debtcollectionmanagement.repository;


import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.debtcollectionmanagement.entity.Debt;

import org.springframework.data.repository.query.Param;

@Repository
public interface DebtRepository extends JpaRepository<Debt, String>{
	@Query("select d from Debt d where month(d.dueDateofPayment)=:month and year(d.dueDateofPayment)=:year_no")
	public List<Debt> findbymonth(@Param("month") int month,@Param("year_no") int year_no);
	
	@Query("SELECT d FROM Debt d WHERE d.month_no=:month and year(d.dueDateofPayment)=:year_no and" +
	"((d.paymentReceiveDate IS NULL AND :currdate > d.dueDateofPayment) OR " +
    "(d.paymentReceiveDate IS NOT NULL AND :year_no*10000+:month*100+14 < year(d.paymentReceiveDate)*10000+month(d.paymentReceiveDate)*100+day(d.paymentReceiveDate)))")
	public List<Debt> findAllDefaulters(@Param("month") int month,@Param("year_no") int year_no,@Param("currdate") LocalDate currdate);
	
	@Query("select d from Debt d where d.month_no=:month and year(d.dueDateofPayment)=:year_no and d.paymentReceiveDate is NULL and d.dueDateofPayment<:currdate")
	public List<Debt> findAllDues(@Param("month") int month,@Param("year_no") int year_no,@Param("currdate") LocalDate currdate);
}
