package com.cognizant.debtcollectionmanagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.debtcollectionmanagement.entity.Debt;
import com.cognizant.debtcollectionmanagement.model.DebtRequestmodel;
import com.cognizant.debtcollectionmanagement.model.DebtResponsemodel;
import com.cognizant.debtcollectionmanagement.repository.DebtRepository;
import com.cognizant.debtcollectionmanagement.service.DebtService;
import com.cognizant.debtcollectionmanagement.service.DebtServiceImp;

class DebtServiceImptest {
	@Mock 
	private Debt debt;
	
	@Mock	
	 DebtRepository debtRepository;
	
	@InjectMocks
	private DebtServiceImp debtServiceImp;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		debt = new Debt();
		debt.setDueDateofPayment(LocalDate.parse("2018-09-03"));
		debt.setLoanAppId("wer123");
		debt.setMonth_no(4);
		debt.setPaymentReceiveDate(LocalDate.parse("2018-09-03"));
		debt.setPaymentTrackId("track567");
		debt.setStatus("Not Received");
	}
	

	@Test
	public void getDebtResponseModels_positive(){	
		List<Debt> mockDebtList =new ArrayList<>();
		mockDebtList.add(debt);
		when(debtRepository.findbymonth(9, 2018)).thenReturn(mockDebtList);
		System.out.println(mockDebtList);
		List<DebtResponsemodel> list= debtServiceImp.getDebtResponseModels(9, 2018);
		assertEquals(1,list.size());
		
	}	
	@Test
	public void getDebtResponseModels_negative() {
		Iterable<DebtResponsemodel> iterableMock = new ArrayList<>();
		Iterable<Debt> DebtList=new ArrayList<>();
		when(debtRepository.findAll()).thenReturn((List<Debt>) DebtList);
		iterableMock = debtServiceImp.getDebtResponseModels(9, 2018);
		assertTrue(((List<DebtResponsemodel>) iterableMock).size()==0);
	}
	
	
	@Test
	public void testcreateDebtRequest_positive() {
		try {
//		Debt debt = Mockito.mock(Debt.class);
		DebtRequestmodel mockDebtRequestmodel= Mockito.mock(DebtRequestmodel.class);
		Optional<Debt> op = Optional.of(debt);
		when(debtRepository.findById(Mockito.anyString())).thenReturn(op);
		when(debtRepository.save(Mockito.any())).thenReturn(debt);
		String result = debtServiceImp.createDebtRequest(mockDebtRequestmodel);
		assertTrue(result=="success");
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	@Test
	public void testcreateDebtRequest_negative() {
		try {
			DebtRequestmodel mockDebtRequestmodel=new DebtRequestmodel();
			when(debtRepository.findById(Mockito.anyString())).thenReturn(null);
			when(debtRepository.save(Mockito.any())).thenReturn(null);
			String result = debtServiceImp.createDebtRequest(mockDebtRequestmodel);
			assertTrue(result=="fail");
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	@Test
	public void testupdateDebtById_positive() {
		try {	
			Optional<Debt> optionalDebt = Optional.of(debt);
			when(debtRepository.findById(Mockito.anyString())).thenReturn(optionalDebt);
			when(debtRepository.save(Mockito.any())).thenReturn(debt);
			String result = debtServiceImp.updateDebtById("wer123");
			assertTrue(result=="success");
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	@Test
	public void testupdateDebtById_negative() {
		try {
			Optional<Debt> optionalOfDebt = Mockito.mock(Optional.class);
			when(debtRepository.findById(Mockito.anyString())).thenReturn(optionalOfDebt);
			String result = debtServiceImp.updateDebtById("gg5");
			assertTrue(result=="fail");
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	@Test
	public void testgetDebtDefaulters_positive() {
		try {
			List<Debt> mocklist = new ArrayList<>();
			mocklist.add(debt);
			when(debtRepository.findAllDefaulters(Mockito.anyInt(),Mockito.anyInt(),Mockito.any())).thenReturn(mocklist);
			List<DebtResponsemodel> result = debtServiceImp.getDebtDefaulters(4,2018);
			assertTrue(result.size()>0);
		}catch(Exception e) {
			
			assertTrue(false);
		}
	}
	@Test
	public void testgetDebtDefaulters_negative() {
		try {
			List<Debt> mocklist = new ArrayList<>();
			when(debtRepository.findAllDefaulters(Mockito.anyInt(),Mockito.anyInt(), Mockito.any())).thenReturn(mocklist);
			List<DebtResponsemodel> result = debtServiceImp.getDebtDefaulters(4,2018);
			assertTrue(result.size()==0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	@Test
	public void testgetDuesData_positive() {
		try {
			List<Debt> mocklist = new ArrayList<>();
			mocklist.add(debt);
			when(debtRepository.findAllDues(Mockito.anyInt(),Mockito.anyInt(),Mockito.any())).thenReturn(mocklist);
			List<DebtResponsemodel> result = debtServiceImp.getDuesData(4,2018);
			assertTrue(result.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testgetDuesData_negative() {
		try {
			List<Debt> mocklist = new ArrayList<>();
			when(debtRepository.findAllDues(Mockito.anyInt(),Mockito.anyInt(),Mockito.any())).thenReturn(mocklist);
			List<DebtResponsemodel> result = debtServiceImp.getDuesData(4,2018);
			assertTrue(result.size()==0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
}
	
	

