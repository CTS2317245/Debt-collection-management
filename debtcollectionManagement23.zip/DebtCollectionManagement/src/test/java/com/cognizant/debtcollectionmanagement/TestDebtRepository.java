package com.cognizant.debtcollectionmanagement;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.debtcollectionmanagement.DebtCollectionManagementApplication;
import com.cognizant.debtcollectionmanagement.entity.Debt;
import com.cognizant.debtcollectionmanagement.repository.DebtRepository;
@DataJpaTest
@ContextConfiguration(classes = DebtCollectionManagementApplication.class)
class TestDebtRepository {
	@Autowired
	private DebtRepository debtRepository;
	@Autowired
	private TestEntityManager entityManager;
	
	private Debt d = new Debt();
	
	private LocalDate localdate = LocalDate.now();
	
	@BeforeEach
	public void init() {
		d.setPaymentTrackId("k97");
		d.setLoanAppId("j89");
		d.setDueDateofPayment(LocalDate.parse("2018-09-10"));
		d.setMonth_no(9);
		d.setPaymentReceiveDate(LocalDate.parse("2018-09-22"));
		d.setStatus("Received");
	}
	
	@Test
	public void testFindAllPositive() {
		System.out.println(d);
		entityManager.persist(d);
		Iterable<Debt> it=debtRepository.findAll();	
		assertEquals(true,it.iterator().hasNext());	
}
	@Test
	public void testFindAllNegative() {
		Iterable<Debt> it=debtRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}


	@Test
	public void testFindByIdPositive() {
		entityManager.persist(d);
		Optional<Debt> debt=debtRepository.findById("j89");
		assertTrue(debt.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Debt> debt=debtRepository.findById("kfk97");
		assertTrue(!debt.isPresent());
	}
	@Test
	public void testSavePositive() {
		debtRepository.save(d);
		Optional<Debt> debt=debtRepository.findById("j89");
		assertTrue(debt.isPresent());
	}
	@Test
	public void testfindAllDefaulters_positive() {
		debtRepository.save(d);
		List<Debt> debt=debtRepository.findAllDefaulters(9,2018,localdate);
		assertTrue(debt.size()>0);
	}
	@Test
	public void testfindAllDefaulters_negative() {
		try
		{
		debtRepository.save(d);
		List<Debt> debt=debtRepository.findAllDefaulters(9,2001,localdate);
		assertTrue(debt.size()==0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
}
