package com.cognizant.debtcollectionmanagement;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;

import com.cognizant.debtcollectionmanagement.controller.DebtController;
import com.cognizant.debtcollectionmanagement.model.DebtRequestmodel;
import com.cognizant.debtcollectionmanagement.model.DebtResponsemodel;
import com.cognizant.debtcollectionmanagement.service.DebtService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest(classes = DebtCollectionManagementApplication.class)
public class TestDebtController {
	 private MockMvc mockMvc;
	 @Mock
	 private DebtService debtService;
	 @InjectMocks
	 private DebtController debtController;
	 
	 private DebtResponsemodel debtResponsemodel;
	 
	 private DebtRequestmodel debtRequestmodel;

	 @BeforeEach
		public void setUp() {
			MockitoAnnotations.initMocks(this);
			debtResponsemodel = new DebtResponsemodel();
		 	debtResponsemodel.setDueDateofPayment(LocalDate.parse("2018-09-03"));
		 	debtResponsemodel.setLoanAppId("wer123");
		 	debtResponsemodel.setMonth_no(4);
		 	debtResponsemodel.setPaymentReceiveDate(LocalDate.parse("2018-09-03"));
		 	debtResponsemodel.setPaymentTrackId("wer123");
		 	debtResponsemodel.setStatus("Not Received");
		 	
		 	debtRequestmodel = new DebtRequestmodel();
			debtRequestmodel.setDueDateofPayment(LocalDate.parse("2018-09-03"));
			debtRequestmodel.setLoanAppId("wer123");
			debtRequestmodel.setMonth_no(4);
			debtRequestmodel.setPaymentReceiveDate(LocalDate.parse("2018-09-03"));
			debtRequestmodel.setPaymentTrackId("wer123");
			debtRequestmodel.setStatus("Not Received");
		}
	 @Test
	 public void testHandleGetAllDebt_positive() {
		 try {
		 	
			List<DebtResponsemodel> responseList = new ArrayList<>();
			responseList.add(debtResponsemodel);
			when(debtService.getDebtResponseModels(Mockito.anyInt(), Mockito.anyInt())).thenReturn(responseList);
			ResponseEntity<?> responseEntity = debtController.handleGetAllDebt(9, 2018);
			List<DebtResponsemodel> actual=(List<DebtResponsemodel>)responseEntity.getBody();
			assertTrue(actual.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	 }
	 @Test
	 public void testHandleGetAllDebt_negative() {
		 try {
			when(debtService.getDebtResponseModels(Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
			ResponseEntity<?> responseEntity = debtController.handleGetAllDebt(Mockito.anyInt(), Mockito.anyInt());
			assertNull(responseEntity);
			}catch(Exception e) {
				assertTrue(true);
			}
	 }
	 @Test
	 public void testHandleGetAllDebt_positiveStatusCode() {
		 try {
			List<DebtResponsemodel> responseList = new ArrayList<>();
			responseList.add(debtResponsemodel);
			when(debtService.getDebtResponseModels(Mockito.anyInt(), Mockito.anyInt())).thenReturn(responseList);
			ResponseEntity<?> responseEntity = debtController.handleGetAllDebt(Mockito.anyInt(), Mockito.anyInt());
			assertEquals(200,responseEntity.getStatusCodeValue());
			}catch(Exception e) {
				assertTrue(false);
			}
	 }
	 @Test
	 public void testHandleGetAllDebt_negativeStatusCode() {
		 try {
				List<DebtResponsemodel> responseList = new ArrayList<>();
				when(debtService.getDebtResponseModels(Mockito.anyInt(), Mockito.anyInt())).thenReturn(responseList);
				ResponseEntity<?> responseEntity = debtController.handleGetAllDebt(Mockito.anyInt(), Mockito.anyInt());
				assertEquals(204,responseEntity.getStatusCodeValue());
			}catch(Exception e) {
				assertTrue(false);
			}
	 }
	 @Test
	 public void testpersistDebt_positive() {
		 try {
			
			 	when(debtService.createDebtRequest(debtRequestmodel)).thenReturn("success");
			 	ResponseEntity<?> responseEntity=debtController.persistDebt(debtRequestmodel);
			 	assertEquals(201,responseEntity.getStatusCodeValue());
		 }catch(Exception e) {
			 assertTrue(false);
		 }
	 }
	 @Test
	 public void testpersistDebt_negative() {
		 try {
			 	when(debtService.createDebtRequest(Mockito.any())).thenReturn("fail");
			 	ResponseEntity<?> responseEntity=debtController.persistDebt(Mockito.mock(DebtRequestmodel.class));
			 	assertEquals(400,responseEntity.getStatusCodeValue());
		 }catch(Exception e) {
			 assertTrue(false);
		 }
	 }
	 @Test
	 public void testupdateDebt_positive() {
		 try {
			 DebtRequestmodel debtRequestmodel = new DebtRequestmodel();
			 	when(debtService.updateDebtById("wer123")).thenReturn("success");
			 	ResponseEntity<?> responseEntity=debtController.updateDebt("wer123");
				assertEquals(200,responseEntity.getStatusCodeValue());
		 }catch(Exception e) {
			 assertTrue(false);
		 }
	 }
	 @Test
	 public void testupdateDebt_negative() {
		 try {
			 DebtRequestmodel debtRequestmodel = new DebtRequestmodel();
			 	when(debtService.updateDebtById("wer123")).thenReturn("fail");
			 	ResponseEntity<?> responseEntity=debtController.updateDebt("wer123");
			 	assertTrue(false);
		 }catch(Exception e) {
			 assertTrue(true);
		 }
	 }
	 @Test
	 public void testgetlistOfDefaulters_positive() {
		 try {
			 	List<DebtResponsemodel> list=new ArrayList<>();
			 	list.add(debtResponsemodel);
			 	when(debtService.getDebtDefaulters(Mockito.anyInt(),Mockito.anyInt())).thenReturn(list);
			 	debtController.getlistOfDefaulters(4,2018);
			 	assertTrue(list.size()>0);
	 }catch(Exception e) {
		 assertTrue(false);
	 }
	 }
	 @Test
	 public void testgetlistOfDefaulters_negative() {
		 try {
			 	when(debtService.getDebtDefaulters(Mockito.anyInt(),Mockito.anyInt())).thenReturn(null);
				debtController.getlistOfDefaulters(4,2018);
	 }catch(Exception e) {
		 assertTrue(true);
	 }
	 }
	 @Test
	 public void testgetlistOfDues_positive() {
		 List<DebtResponsemodel> list=new ArrayList<>();
		 list.add(debtResponsemodel);
		 when(debtService.getDuesData(Mockito.anyInt(),Mockito.anyInt())).thenReturn(list);
		 ResponseEntity<?> responseEntity=debtController.getlistOfDues(Mockito.anyInt(),Mockito.anyInt());
		 List<DebtResponsemodel> result = (List<DebtResponsemodel>) responseEntity.getBody();
		 assertTrue(result.size()>0);
	 }
	 @Test
	 public void testgetlistOfDues_negative() {
		 List<DebtResponsemodel> list=new ArrayList<>();
		 when(debtService.getDuesData(Mockito.anyInt(),Mockito.anyInt())).thenReturn(list);
		 ResponseEntity<?> responseEntity=debtController.getlistOfDues(Mockito.anyInt(),Mockito.anyInt());
		 List<DebtResponsemodel> result = (List<DebtResponsemodel>) responseEntity.getBody();
		 assertTrue(result.size()==0);
	 }
}
